package com.acon.prac4.데이터응답;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Acorn {

	String name;
	String addr;
}
