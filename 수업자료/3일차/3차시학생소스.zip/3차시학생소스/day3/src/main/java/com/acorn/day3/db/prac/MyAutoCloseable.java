package com.acorn.day3.db.prac;

public interface MyAutoCloseable {
	
	public void close();

}
