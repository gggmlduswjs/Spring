package com.acorn.day3.db;

import lombok.Data;

@Data
public class User {
	String id;
	String pw;
	

}
