package com.acorn.day3.api;

import lombok.Data;

@Data
public class Drama {
	
	String name;
	String actor; 
	
	
}
