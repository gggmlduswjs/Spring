package com.acorn.prac;

import org.springframework.stereotype.Component;

@Component
public class A {
	
	public void a() {
		System.out.println( " a  method");
	}

}
