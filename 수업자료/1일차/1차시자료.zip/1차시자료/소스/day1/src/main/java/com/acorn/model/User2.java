package com.acorn.model;

import lombok.Data;
import lombok.RequiredArgsConstructor;
 
@Data
public class User2 {

	String id;
	String pw;
	
	
	
	
}
