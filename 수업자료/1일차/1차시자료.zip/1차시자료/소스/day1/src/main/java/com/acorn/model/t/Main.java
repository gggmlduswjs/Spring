package com.acorn.model.t;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Member m = new Member();
		m.setPw("1234");
		m.setId("11");
		
		
		
		System.out.println( m);
	}

}
