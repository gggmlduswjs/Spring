package com.acorn.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


//롬복 사용하기 
 //@NoArgsConstructor
 //@AllArgsConstructor
 @Data
public class Customer {
	
	String name;
	String addr;
	
	
	

}
