package com.acorn.param;

import lombok.Data;

@Data
public class Book2 {
	
	String id;
	String name;
	
	
}
