package com.acorn.di.calculator;

public class Test {
	
	
	public void test() {
		System.out.println("test");
	}

}
