package com.acorn.prac.mvc;

public class Case연습 {
	
	public static void main(String[] args) {
		
		//
		
		int menu=7;	// 1,2,3,4,5
		
		switch(menu) {
		case 1:
			System.out.println("등록합니다");
		case 2:
			System.out.println("변경합니다");
			break;
		
		}
	}

}
